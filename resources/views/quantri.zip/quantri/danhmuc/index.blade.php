@extends('quantri.layoutquantri')
@section('pagetitle', 'DANH SÁCH DANH MỤC')    
@section('main')
    @include("quantri/danhmuc/loopdanhmuc")
@endsection