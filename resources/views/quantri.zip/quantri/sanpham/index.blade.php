@extends('quantri.layoutquantri')
@section('pagetitle', 'DANH SÁCH SẢN PHẨM')    
@section('main')
    @include("quantri/sanpham/loopsanpham")
@endsection