@extends('quantri.layoutquantri')
@section('pagetitle', 'DANH SÁCH KHÁCH HÀNG')    
@section('main')
    @include("quantri/khachhang/loopkhachhang")
@endsection