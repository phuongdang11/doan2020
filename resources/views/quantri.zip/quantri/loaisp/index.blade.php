@extends('quantri.layoutquantri')
@section('pagetitle', 'DANH SÁCH LOẠI SẢN PHẨM')    
@section('main')
    @include("quantri/loaisp/looploaisp")
@endsection